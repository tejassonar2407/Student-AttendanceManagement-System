package com.group6.attendance;

import com.group6.attendance.db.AttendanceDAO;
import com.group6.attendance.db.Database;
import com.group6.attendance.model.Student;
import com.group6.attendance.util.InvalidRollNoException;
import com.group6.attendance.util.ReportTask;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class MainApp extends JFrame {
    private final AttendanceDAO dao = new AttendanceDAO();
    private final JTextArea output = new JTextArea(5, 40);
    private final JComboBox<Student> studentBox = new JComboBox<>();
    private final JComboBox<SubjectItem> subjectBox = new JComboBox<>();
    private final JComboBox<String> statusBox = new JComboBox<>(new String[]{"Present", "Absent"});
    private final JTextField dateField = new JTextField(LocalDate.now().toString(), 10);
    private final DefaultTableModel reportModel = new DefaultTableModel(
        new String[]{"Roll No.", "Student", "Subject", "Present/Total", "Percentage"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable reportTable = new JTable(reportModel);

    public MainApp() {
        super("Group 6 - Student Attendance Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(920, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel heading = new JLabel("STUDENT ATTENDANCE MANAGEMENT SYSTEM", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 20));
        heading.setBorder(BorderFactory.createEmptyBorder(15, 8, 8, 8));
        add(heading, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Student Records", studentPanel());
        tabs.addTab("Subject Records", subjectPanel());
        tabs.addTab("Daily Attendance", attendancePanel());
        tabs.addTab("Reports", reportPanel());
        add(tabs, BorderLayout.CENTER);

        output.setEditable(false);
        output.setLineWrap(true);
        add(new JScrollPane(output), BorderLayout.SOUTH);
        refreshCombos();
        refreshReport();
    }

    private JPanel studentPanel() {
        JTextField roll = new JTextField(), name = new JTextField(), uid = new JTextField();
        JPanel form = new JPanel(new GridLayout(4, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35));
        form.add(new JLabel("Roll Number:")); form.add(roll);
        form.add(new JLabel("Student Name:")); form.add(name);
        form.add(new JLabel("UID:")); form.add(uid);
        JButton add = new JButton("Add Student");
        form.add(new JLabel("")); form.add(add);
        add.addActionListener(e -> {
            try {
                if (roll.getText().isBlank() || name.getText().isBlank() || uid.getText().isBlank())
                    throw new IllegalArgumentException("Please fill all student fields.");
                dao.addStudent(new Student(roll.getText().trim(), name.getText().trim(), uid.getText().trim()));
                message("Student added successfully.");
                roll.setText(""); name.setText(""); uid.setText("");
                refreshCombos(); refreshReport();
            } catch (Exception ex) { showError(ex); }
        });
        return form;
    }

    private JPanel subjectPanel() {
        JTextField code = new JTextField(), name = new JTextField();
        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(35, 35, 35, 35));
        form.add(new JLabel("Subject Code:")); form.add(code);
        form.add(new JLabel("Subject Name:")); form.add(name);
        JButton add = new JButton("Add Subject");
        form.add(new JLabel("")); form.add(add);
        add.addActionListener(e -> {
            try {
                if (code.getText().isBlank() || name.getText().isBlank())
                    throw new IllegalArgumentException("Please enter subject code and name.");
                dao.addSubject(code.getText().trim(), name.getText().trim());
                message("Subject added successfully.");
                code.setText(""); name.setText("");
                refreshCombos(); refreshReport();
            } catch (Exception ex) { showError(ex); }
        });
        return form;
    }

    private JPanel attendancePanel() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        JPanel form = new JPanel(new GridLayout(5, 2, 10, 12));
        form.setBorder(BorderFactory.createEmptyBorder(30, 35, 20, 35));
        form.add(new JLabel("Student:")); form.add(studentBox);
        form.add(new JLabel("Subject:")); form.add(subjectBox);
        form.add(new JLabel("Date (YYYY-MM-DD):")); form.add(dateField);
        form.add(new JLabel("Status:")); form.add(statusBox);
        JButton mark = new JButton("Save Attendance");
        form.add(new JLabel("")); form.add(mark);
        mark.addActionListener(e -> {
            try {
                Student student = (Student) studentBox.getSelectedItem();
                SubjectItem subject = (SubjectItem) subjectBox.getSelectedItem();
                if (student == null || subject == null)
                    throw new IllegalArgumentException("Add at least one student and one subject first.");
                LocalDate.parse(dateField.getText().trim());
                dao.markAttendance(student.getRollNo(), subject.code, dateField.getText().trim(),
                    (String) statusBox.getSelectedItem());
                message("Attendance saved. You can update the same student's status for this subject and date.");
                refreshReport();
            } catch (InvalidRollNoException ex) { showError(ex); }
              catch (Exception ex) { showError(ex); }
        });
        panel.add(form, BorderLayout.NORTH);
        return panel;
    }

    private JPanel reportPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton refresh = new JButton("Refresh Report");
        JButton shortage = new JButton("Show Shortage List (<75%)");
        JButton export = new JButton("Export CSV (Background Thread)");
        actions.add(refresh); actions.add(shortage); actions.add(export);
        refresh.addActionListener(e -> refreshReport());
        shortage.addActionListener(e -> {
            try {
                List<String[]> rows = dao.getShortageRows(75.0);
                setRows(rows);
                message("Shortage list: " + rows.size() + " student-subject record(s) below 75%.");
            } catch (Exception ex) { showError(ex); }
        });
        export.addActionListener(e -> {
            message("Generating report in background...");
            Thread thread = new Thread(new ReportTask(msg ->
                SwingUtilities.invokeLater(() -> message(msg))), "attendance-report-thread");
            thread.start();
        });
        panel.add(actions, BorderLayout.NORTH);
        panel.add(new JScrollPane(reportTable), BorderLayout.CENTER);
        return panel;
    }

    private void refreshCombos() {
        try {
            studentBox.removeAllItems();
            for (Student s : dao.getStudents()) studentBox.addItem(s);
            subjectBox.removeAllItems();
            for (String[] s : dao.getSubjects()) subjectBox.addItem(new SubjectItem(s[0], s[1]));
        } catch (SQLException ex) { showError(ex); }
    }

    private void refreshReport() {
        try { setRows(dao.getReportRows()); }
        catch (Exception ex) { showError(ex); }
    }

    private void setRows(List<String[]> rows) {
        reportModel.setRowCount(0);
        for (String[] row : rows) reportModel.addRow(row);
    }

    private void message(String text) { output.setText(text); }
    private void showError(Exception ex) {
        message("Error: " + ex.getMessage());
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    private static class SubjectItem {
        final String code, name;
        SubjectItem(String code, String name) { this.code = code; this.name = name; }
        @Override public String toString() { return code + " - " + name; }
    }

    public static void main(String[] args) {
        try { Database.initialize(); }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database initialization failed: " + ex.getMessage());
            return;
        }
        SwingUtilities.invokeLater(() -> new MainApp().setVisible(true));
    }
}
