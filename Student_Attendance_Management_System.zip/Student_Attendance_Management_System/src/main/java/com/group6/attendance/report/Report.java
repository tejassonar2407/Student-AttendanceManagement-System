package com.group6.attendance.report;

import java.io.File;
import java.sql.SQLException;

public abstract class Report {
    public abstract File generate() throws Exception;
}
