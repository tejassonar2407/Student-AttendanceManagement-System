# Group 6 - Student Attendance Management System

A Java 17 + Swing + SQLite desktop project based on the assignment sheet.

## Features
- Add student records and subject records
- Mark daily attendance (Present / Absent)
- Calculate subject-wise attendance percentage
- Generate a shortage list (below 75%)
- Export attendance reports to CSV
- SQLite database is created automatically in the project folder (`attendance.db`)

## Requirements
- JDK 17 or newer
- Apache Maven
- VS Code with the **Extension Pack for Java** (recommended)

## Run in VS Code
1. Extract this ZIP file.
2. Open the extracted `Student_Attendance_Management_System` folder in VS Code.
3. Open **Terminal > New Terminal**.
4. Check Java and Maven:
   ```bash
   java -version
   mvn -version
   ```
5. Run:
   ```bash
   mvn clean compile exec:java
   ```
   The first run needs an internet connection so Maven can download the SQLite library.
6. The application window will open. Add students and subjects first, then mark attendance.

## Database
The application automatically creates these SQLite tables:
- `students`
- `subjects`
- `attendance`

The database file is stored as `attendance.db` in the folder from which you run Maven.

## Project structure
```text
src/main/java/com/group6/attendance/
  MainApp.java
  model/
    Person.java
    Student.java
    Faculty.java
  db/
    Database.java
    AttendanceDAO.java
  report/
    Report.java
    AttendanceReport.java
  util/
    InvalidRollNoException.java
    ReportTask.java
```

## Assignment concepts covered
- Arrays / loops / selection statements: table population and report processing
- File class: CSV report export
- Inheritance: `Student` and `Faculty` extend `Person`
- Abstract class: `Report`
- Package: `attendance.util`
- Custom exception: `InvalidRollNoException`
- Runnable thread: report generation runs in a background thread
- JDBC: `PreparedStatement`, `executeUpdate()`, and `ResultSet` traversal
- Swing: `JTextField`, `JButton`, `JTextArea`, `GridLayout`, `ActionListener`
