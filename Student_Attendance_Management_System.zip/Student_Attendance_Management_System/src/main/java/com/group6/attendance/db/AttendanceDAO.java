package com.group6.attendance.db;

import com.group6.attendance.model.Student;
import com.group6.attendance.util.InvalidRollNoException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AttendanceDAO {
    public void addStudent(Student s) throws SQLException {
        try (Connection c = Database.getConnection();
             PreparedStatement p = c.prepareStatement(
                 "INSERT INTO students(roll_no,name,uid) VALUES(?,?,?)")) {
            p.setString(1, s.getRollNo());
            p.setString(2, s.getName());
            p.setString(3, s.getUid());
            p.executeUpdate();
        }
    }

    public void addSubject(String code, String name) throws SQLException {
        try (Connection c = Database.getConnection();
             PreparedStatement p = c.prepareStatement(
                 "INSERT INTO subjects(subject_code,subject_name) VALUES(?,?)")) {
            p.setString(1, code);
            p.setString(2, name);
            p.executeUpdate();
        }
    }

    public List<Student> getStudents() throws SQLException {
        List<Student> list = new ArrayList<>();
        try (Connection c = Database.getConnection();
             PreparedStatement p = c.prepareStatement(
                 "SELECT roll_no,name,uid FROM students ORDER BY roll_no");
             ResultSet rs = p.executeQuery()) {
            while (rs.next()) {
                list.add(new Student(rs.getString("roll_no"),
                    rs.getString("name"), rs.getString("uid")));
            }
        }
        return list;
    }

    public List<String[]> getSubjects() throws SQLException {
        List<String[]> list = new ArrayList<>();
        try (Connection c = Database.getConnection();
             PreparedStatement p = c.prepareStatement(
                 "SELECT subject_code,subject_name FROM subjects ORDER BY subject_name");
             ResultSet rs = p.executeQuery()) {
            while (rs.next()) {
                list.add(new String[]{rs.getString(1), rs.getString(2)});
            }
        }
        return list;
    }

    public void markAttendance(String roll, String subject, String date, String status)
            throws SQLException, InvalidRollNoException {
        try (Connection c = Database.getConnection()) {
            try (PreparedStatement check = c.prepareStatement(
                    "SELECT 1 FROM students WHERE roll_no=?")) {
                check.setString(1, roll);
                try (ResultSet rs = check.executeQuery()) {
                    if (!rs.next()) throw new InvalidRollNoException("Student roll number not found.");
                }
            }
            try (PreparedStatement p = c.prepareStatement("""
                    INSERT INTO attendance(roll_no,subject_code,attendance_date,status)
                    VALUES(?,?,?,?)
                    ON CONFLICT(roll_no,subject_code,attendance_date)
                    DO UPDATE SET status=excluded.status
                    """)) {
                p.setString(1, roll);
                p.setString(2, subject);
                p.setString(3, date);
                p.setString(4, status);
                p.executeUpdate();
            }
        }
    }

    public List<String[]> getReportRows() throws SQLException {
        List<String[]> rows = new ArrayList<>();
        String sql = """
            SELECT s.roll_no, s.name, sub.subject_name,
                   SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present_count,
                   COUNT(a.id) AS total_count,
                   CASE WHEN COUNT(a.id)=0 THEN 0
                        ELSE ROUND(100.0*SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END)/COUNT(a.id),2)
                   END AS percentage
            FROM students s
            CROSS JOIN subjects sub
            LEFT JOIN attendance a
              ON a.roll_no=s.roll_no AND a.subject_code=sub.subject_code
            GROUP BY s.roll_no,s.name,sub.subject_code,sub.subject_name
            ORDER BY s.roll_no,sub.subject_name
            """;
        try (Connection c = Database.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet rs = p.executeQuery()) {
            while (rs.next()) {
                rows.add(new String[]{
                    rs.getString("roll_no"), rs.getString("name"),
                    rs.getString("subject_name"),
                    rs.getInt("present_count") + "/" + rs.getInt("total_count"),
                    rs.getString("percentage") + "%"
                });
            }
        }
        return rows;
    }

    public List<String[]> getShortageRows(double threshold) throws SQLException {
        List<String[]> result = new ArrayList<>();
        for (String[] row : getReportRows()) {
            double percentage = Double.parseDouble(row[4].replace("%", ""));
            if (!row[3].equals("0/0") && percentage < threshold) result.add(row);
        }
        return result;
    }
}
