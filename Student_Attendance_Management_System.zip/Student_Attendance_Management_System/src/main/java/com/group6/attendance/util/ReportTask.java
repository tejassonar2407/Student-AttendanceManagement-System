package com.group6.attendance.util;

import com.group6.attendance.report.AttendanceReport;
import java.io.File;
import java.util.function.Consumer;

public class ReportTask implements Runnable {
    private final Consumer<String> callback;

    public ReportTask(Consumer<String> callback) {
        this.callback = callback;
    }

    @Override
    public void run() {
        try {
            File file = new AttendanceReport().generate();
            callback.accept("Report generated successfully:\n" + file.getAbsolutePath());
        } catch (Exception ex) {
            callback.accept("Could not generate report: " + ex.getMessage());
        }
    }
}
