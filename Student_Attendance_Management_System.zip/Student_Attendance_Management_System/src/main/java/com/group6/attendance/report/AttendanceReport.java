package com.group6.attendance.report;

import com.group6.attendance.db.AttendanceDAO;
import java.io.File;
import java.io.PrintWriter;
import java.util.List;

public class AttendanceReport extends Report {
    @Override
    public File generate() throws Exception {
        File file = new File("Attendance_Report.csv");
        List<String[]> rows = new AttendanceDAO().getReportRows();
        try (PrintWriter out = new PrintWriter(file, "UTF-8")) {
            out.println("Roll Number,Student Name,Subject,Present/Total,Attendance Percentage");
            for (String[] row : rows) {
                out.println(csv(row[0]) + "," + csv(row[1]) + "," + csv(row[2]) + "," +
                            csv(row[3]) + "," + csv(row[4]));
            }
        }
        return file;
    }

    private String csv(String value) {
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }
}
