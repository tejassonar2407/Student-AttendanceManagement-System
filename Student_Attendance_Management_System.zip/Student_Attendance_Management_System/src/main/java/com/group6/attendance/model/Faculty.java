package com.group6.attendance.model;

public class Faculty extends Person {
    private final String employeeId;

    public Faculty(String employeeId, String name, String uid) {
        super(name, uid);
        this.employeeId = employeeId;
    }

    public String getEmployeeId() { return employeeId; }
}
