package com.group6.attendance.model;

public abstract class Person {
    protected String name;
    protected String uid;

    public Person(String name, String uid) {
        this.name = name;
        this.uid = uid;
    }

    public String getName() { return name; }
    public String getUid() { return uid; }
}
