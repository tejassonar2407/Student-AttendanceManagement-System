package com.group6.attendance.util;

public class InvalidRollNoException extends Exception {
    public InvalidRollNoException(String message) {
        super(message);
    }
}
