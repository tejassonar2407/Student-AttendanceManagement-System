package com.group6.attendance.model;

public class Student extends Person {
    private final String rollNo;

    public Student(String rollNo, String name, String uid) {
        super(name, uid);
        this.rollNo = rollNo;
    }

    public String getRollNo() { return rollNo; }

    @Override
    public String toString() {
        return rollNo + " - " + name;
    }
}
